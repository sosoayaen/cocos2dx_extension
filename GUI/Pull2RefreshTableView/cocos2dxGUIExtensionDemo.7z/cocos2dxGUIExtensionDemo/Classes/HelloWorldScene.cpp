#include "HelloWorldScene.h"
#include "cmath"

USING_NS_CC;
USING_NS_CC_EXT;

CCScene* HelloWorld::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    HelloWorld *layer = HelloWorld::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !CCLayer::init() )
    {
        return false;
    }

	m_pTableView = NULL;
	m_pItemModel = NULL;
    
    CCSize visibleSize = CCDirector::sharedDirector()->getVisibleSize();
    CCPoint origin = CCDirector::sharedDirector()->getVisibleOrigin();

    /////////////////////////////
    // 2. add a menu item with "X" image, which is clicked to quit the program
    //    you may modify it.

    // add a "close" icon to exit the progress. it's an autorelease object
    CCMenuItemImage *pCloseItem = CCMenuItemImage::create(
                                        "CloseNormal.png",
                                        "CloseSelected.png",
                                        this,
                                        menu_selector(HelloWorld::menuCloseCallback));
    
	pCloseItem->setPosition(ccp(origin.x + visibleSize.width - pCloseItem->getContentSize().width/2 ,
                                origin.y + pCloseItem->getContentSize().height/2));

    // create menu, it's an autorelease object
    CCMenu* pMenu = CCMenu::create(pCloseItem, NULL);
    pMenu->setPosition(CCPointZero);
    this->addChild(pMenu, 1);

    /////////////////////////////
    // 3. add your codes below...

    // add a label shows "Hello World"
    // create and initialize a label
    
    CCLabelTTF* pLabel = CCLabelTTF::create("Hello pis", "Arial", 48);
    
    // position the label on the center of the screen
    pLabel->setPosition(ccp(origin.x + visibleSize.width/2,
                            origin.y + visibleSize.height - pLabel->getContentSize().height));

    // add the label as a child to this layer
    this->addChild(pLabel, 1);

    // add "HelloWorld" splash screen"
    CCSprite* pSprite = CCSprite::create("HelloWorld.png");

    // position the sprite on the center of the screen
    pSprite->setPosition(ccp(visibleSize.width/2 + origin.x, visibleSize.height/2 + origin.y));

    // add the sprite as a child to this layer
    this->addChild(pSprite, 0);

	// Add cctableview in the center
	m_pItemModel = CCSprite::create("item_bg.png");
	m_pItemModel->retain();

	// create the header node
	CCNode* header = CCNode::create();
	m_pSpritePullDown = CCSprite::create("CloseNormal.png");
	header->setContentSize(CCSizeMake(m_pItemModel->getContentSize().width, 
				m_pSpritePullDown->getContentSize().height));

	m_pSpritePullDown->setPosition(ccpMult(ccpFromSize(header->getContentSize()), 0.5f));

	m_pLabelTTFPullDownTips1 = CCLabelTTF::create("Pull down", "", 20);
	m_pLabelTTFPullDownTips1->setPosition(ccp(m_pSpritePullDown->getPositionX(),
				m_pSpritePullDown->getPositionY()+m_pSpritePullDown->getContentSize().height));

	m_pLabelTTFPullDownTips2 = CCLabelTTF::create("Release to REFRESH", "", 20);
	m_pLabelTTFPullDownTips2->setPosition(m_pLabelTTFPullDownTips1->getPosition());
	m_pLabelTTFPullDownTips2->setVisible(false);

	header->addChild(m_pSpritePullDown);
	header->addChild(m_pLabelTTFPullDownTips1);
	header->addChild(m_pLabelTTFPullDownTips2);

	// create the footer node
	CCNode* footer = CCNode::create();
	m_pSpritePullUp = CCSprite::create("CloseNormal.png");
	footer->setContentSize(header->getContentSize());

	m_pSpritePullUp->setPosition(m_pSpritePullDown->getPosition());

	m_pLabelTTFPullUpTips1 = CCLabelTTF::create("Pull Up", "", 20);
	m_pLabelTTFPullUpTips1->setPosition(ccp(m_pSpritePullUp->getPositionX(),
				m_pSpritePullUp->getPositionY()-m_pSpritePullUp->getContentSize().height));

	m_pLabelTTFPullUpTips2 = CCLabelTTF::create("Release to REFRESH", "", 20);
	m_pLabelTTFPullUpTips2->setPosition(m_pLabelTTFPullUpTips1->getPosition());
	m_pLabelTTFPullUpTips2->setVisible(false);

	footer->addChild(m_pSpritePullUp);
	footer->addChild(m_pLabelTTFPullUpTips1);
	footer->addChild(m_pLabelTTFPullUpTips2);

	// create a pull2refreshtableview object
    m_pTableView = Pull2RefreshTableView::create(this, 
		CCSizeMake(m_pItemModel->getContentSize().width, this->getContentSize().height*0.5f),
		NULL, // container
		header,
		footer);

	m_pTableView->setPullDownOffsetThreshold(100);
	m_pTableView->setPullUpOffsetThreshold(100);
	m_pTableView->setDelegate(this);
	m_pTableView->setDirection(kCCScrollViewDirectionVertical);
	m_pTableView->setVerticalFillOrder(kCCTableViewFillTopDown);
	m_pTableView->setPosition(ccpMult(ccpFromSize(this->getContentSize()), 0.25f));
	m_pTableView->reloadData();

	addChild(m_pTableView);

    return true;
}


void HelloWorld::menuCloseCallback(CCObject* pSender)
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WINRT) || (CC_TARGET_PLATFORM == CC_PLATFORM_WP8)
	CCMessageBox("You pressed the close button. Windows Store Apps do not implement a close button.","Alert");
#else
    CCDirector::sharedDirector()->end();
#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    exit(0);
#endif
#endif
}

CCTableViewCell* HelloWorld::tableCellAtIndex( CCTableView *table, unsigned int idx )
{
	CCTableViewCell* pCell = table->dequeueCell();
	if (!pCell)
	{
		pCell = new CCTableViewCell;
		if (pCell)
		{
			pCell->autorelease();
		}
	}

	if (pCell)
	{
		pCell->removeAllChildren();

		CCSprite* pSpriteCellBG = CCSprite::create("item_bg.png");
		pSpriteCellBG->setAnchorPoint(CCPointZero);
		pCell->addChild(pSpriteCellBG);
	}

	return pCell;
}

unsigned int HelloWorld::numberOfCellsInTableView( CCTableView *table )
{
	return 25;
}

void HelloWorld::tableCellTouched( CCTableView* table, CCTableViewCell* cell )
{
	// CCLOG("touched %i", cell->getIdx());
}

void HelloWorld::scrollViewDidScroll( CCScrollView* view )
{
	CCPoint posOffset = view->getContentOffset();
	CCSize size = view->getContentSize();
//	CCLOG("size: (%0.2f, %0.2f), posOffset: (%0.2f, %0.2f)", size.width, size.height, posOffset.x, posOffset.y);
}

void HelloWorld::scrollViewDidZoom( CCScrollView* view )
{
}

cocos2d::CCSize HelloWorld::tableCellSizeForIndex( CCTableView *table, unsigned int idx )
{
	return cellSizeForTable(table);
}

cocos2d::CCSize HelloWorld::cellSizeForTable( CCTableView *table )
{
	return m_pItemModel->getContentSize();
}

bool HelloWorld::onPullDownRefresh( Pull2RefreshTableView* table )
{
	// TODO: refresh the pull down's data
	CCLOG("HelloWorld::onPullDownRefresh");
	return true;
}

bool HelloWorld::onPullUpRefresh( Pull2RefreshTableView* table )
{
	// TODO: refresh the pull up's data
	CCLOG("HelloWorld::onPullUpRefresh");
	return true;
}

void HelloWorld::onPullDownDidScroll( Pull2RefreshTableView* table, float fDistance, float fThreshold )
{
	float fDis = fDistance;
	bool bMatchReleaseRefresh = fDistance > fThreshold;
	if (bMatchReleaseRefresh)
	{
		fDis = fThreshold;
	}
	m_pLabelTTFPullDownTips1->setVisible(!bMatchReleaseRefresh);
	m_pLabelTTFPullDownTips2->setVisible(bMatchReleaseRefresh);	

	float fDegree = 540*fDis/fThreshold;
	if (m_pSpritePullDown)
	{
		m_pSpritePullDown->setRotation(fDegree);
	}

	// CCLOG("degree:%0.2f, dis:%0.2f, stantard:%0.2f", fDegree, fDistance, fThreshold);
}

void HelloWorld::onPullUpDidScroll( Pull2RefreshTableView* table, float fDistance, float fThreshold )
{
	float fDis = fDistance;
	bool bMatchReleaseRefresh = fDistance > fThreshold;
	if (bMatchReleaseRefresh)
	{
		fDis = fThreshold;
	}
	m_pLabelTTFPullUpTips1->setVisible(!bMatchReleaseRefresh);
	m_pLabelTTFPullUpTips2->setVisible(bMatchReleaseRefresh);	

	float fDegree = 540*fDis/fThreshold;
	if (m_pSpritePullUp)
	{
		m_pSpritePullUp->setRotation(fDegree);
	}
}
