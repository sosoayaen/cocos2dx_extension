#ifndef __HELLOWORLD_SCENE_H__
#define __HELLOWORLD_SCENE_H__

#include "cocos2d.h"
#include "cocos-ext.h"
#include "Pull2RefreshTableView.h"

class HelloWorld : public cocos2d::CCLayer
	, public cocos2d::extension::CCTableViewDataSource
	, public Pull2RefreshTableViewDelegate
{
public:
    // Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
    virtual bool init();  

    // there's no 'id' in cpp, so we recommend returning the class instance pointer
    static cocos2d::CCScene* scene();
    
    // a selector callback
    void menuCloseCallback(CCObject* pSender);
    
    // implement the "static node()" method manually
    CREATE_FUNC(HelloWorld);

	virtual cocos2d::extension::CCTableViewCell* tableCellAtIndex( cocos2d::extension::CCTableView *table, unsigned int idx );

	virtual unsigned int numberOfCellsInTableView( cocos2d::extension::CCTableView *table );

	virtual void tableCellTouched( cocos2d::extension::CCTableView* table, cocos2d::extension::CCTableViewCell* cell );

	virtual void scrollViewDidScroll( cocos2d::extension::CCScrollView* view );

	virtual void scrollViewDidZoom( cocos2d::extension::CCScrollView* view );

	virtual cocos2d::CCSize tableCellSizeForIndex( cocos2d::extension::CCTableView *table, unsigned int idx );

	virtual cocos2d::CCSize cellSizeForTable( cocos2d::extension::CCTableView *table );

	virtual bool onPullDownRefresh( Pull2RefreshTableView* table );

	virtual bool onPullUpRefresh( Pull2RefreshTableView* table );

	virtual void onPullDownDidScroll( Pull2RefreshTableView* table, float fDistance, float fThreshold);

	virtual void onPullUpDidScroll( Pull2RefreshTableView* table, float fDistance, float fThreshold);

private:
	Pull2RefreshTableView* m_pTableView;

	cocos2d::CCSprite* m_pItemModel;

	cocos2d::CCSprite* m_pSpritePullDown;
	cocos2d::CCSprite* m_pSpritePullUp;

	cocos2d::CCLabelTTF* m_pLabelTTFPullDownTips1;
	cocos2d::CCLabelTTF* m_pLabelTTFPullDownTips2;
	
	cocos2d::CCLabelTTF* m_pLabelTTFPullUpTips1;
	cocos2d::CCLabelTTF* m_pLabelTTFPullUpTips2;
};

#endif // __HELLOWORLD_SCENE_H__
